
  # SaaS for Book Merch Store

  This is a code bundle for SaaS for Book Merch Store. The original project is available at https://www.figma.com/design/eKk211xjXWkTcWVhhZzXYm/SaaS-for-Book-Merch-Store.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  