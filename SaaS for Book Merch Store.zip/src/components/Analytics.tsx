import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { TransactionData } from './DataUpload';
import { TrendingUp, Package, DollarSign, Users } from 'lucide-react';

interface AnalyticsProps {
  data: TransactionData[];
}

export function Analytics({ data }: AnalyticsProps) {
  const analytics = useMemo(() => {
    // Total items sold
    const totalFrequency = data.reduce((sum, item) => sum + item.frequency, 0);
    
    // Total revenue (if price data available)
    const totalRevenue = data.reduce((sum, item) => 
      sum + (item.frequency * (item.price || 0)), 0
    );
    
    // Top selling items
    const topItems = [...data]
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, 10);
    
    // Category analysis
    const categoryData = data.reduce((acc, item) => {
      const category = item.category || 'Uncategorized';
      if (!acc[category]) {
        acc[category] = { name: category, frequency: 0, revenue: 0, items: 0 };
      }
      acc[category].frequency += item.frequency;
      acc[category].revenue += item.frequency * (item.price || 0);
      acc[category].items += 1;
      return acc;
    }, {} as Record<string, { name: string; frequency: number; revenue: number; items: number }>);
    
    const categories = Object.values(categoryData);
    
    // Price range analysis
    const priceRanges = data.filter(item => item.price).reduce((acc, item) => {
      const price = item.price!;
      let range = '';
      if (price < 5) range = '$0-5';
      else if (price < 10) range = '$5-10';
      else if (price < 20) range = '$10-20';
      else if (price < 50) range = '$20-50';
      else range = '$50+';
      
      if (!acc[range]) {
        acc[range] = { name: range, frequency: 0, revenue: 0 };
      }
      acc[range].frequency += item.frequency;
      acc[range].revenue += item.frequency * price;
      return acc;
    }, {} as Record<string, { name: string; frequency: number; revenue: number }>);
    
    return {
      totalFrequency,
      totalRevenue,
      topItems,
      categories,
      priceRanges: Object.values(priceRanges),
      averageItemPrice: totalRevenue / totalFrequency || 0,
      uniqueItems: data.length
    };
  }, [data]);

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#a4de6c', '#d084d0', '#8dd1e1', '#ffb347'];

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Transaction Analytics</h1>
          <p className="text-muted-foreground">
            Insights from your transaction history
          </p>
        </div>
        <Badge variant="secondary">
          {analytics.uniqueItems} unique items
        </Badge>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Items Sold</p>
                <p className="text-2xl font-medium">{analytics.totalFrequency.toLocaleString()}</p>
              </div>
              <Package className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        {analytics.totalRevenue > 0 && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                  <p className="text-2xl font-medium">${analytics.totalRevenue.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        )}
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unique Products</p>
                <p className="text-2xl font-medium">{analytics.uniqueItems}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        {analytics.averageItemPrice > 0 && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Item Value</p>
                  <p className="text-2xl font-medium">${analytics.averageItemPrice.toFixed(2)}</p>
                </div>
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Items Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Items</CardTitle>
            <CardDescription>Items ranked by frequency sold</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analytics.topItems}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="itemName" 
                  angle={-45}
                  textAnchor="end"
                  height={100}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [value, 'Frequency']}
                  labelFormatter={(label) => `Item: ${label}`}
                />
                <Bar dataKey="frequency" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Distribution Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Sales by Category</CardTitle>
            <CardDescription>Distribution of sales across product categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analytics.categories}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="frequency"
                >
                  {analytics.categories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [value, 'Items Sold']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Additional Charts if revenue data available */}
      {analytics.totalRevenue > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Price Range Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Sales by Price Range</CardTitle>
              <CardDescription>Revenue distribution across price ranges</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.priceRanges}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value, name) => [
                    name === 'revenue' ? `$${value}` : value,
                    name === 'revenue' ? 'Revenue' : 'Items Sold'
                  ]} />
                  <Bar dataKey="frequency" fill="#82ca9d" name="Items Sold" />
                  <Bar dataKey="revenue" fill="#ffc658" name="Revenue" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Category Revenue */}
          <Card>
            <CardHeader>
              <CardTitle>Revenue by Category</CardTitle>
              <CardDescription>Total revenue generated per category</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.categories}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    fontSize={12}
                  />
                  <YAxis />
                  <Tooltip formatter={(value, name) => [`$${value}`, 'Revenue']} />
                  <Bar dataKey="revenue" fill="#ff7300" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Top Items Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Item Performance</CardTitle>
          <CardDescription>Complete breakdown of your best-performing items</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Item Name</th>
                  <th className="text-left p-2">Category</th>
                  <th className="text-right p-2">Frequency</th>
                  {analytics.totalRevenue > 0 && (
                    <>
                      <th className="text-right p-2">Price</th>
                      <th className="text-right p-2">Total Revenue</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
                {analytics.topItems.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-muted/50">
                    <td className="p-2">{item.itemName}</td>
                    <td className="p-2">
                      <Badge variant="outline">{item.category || 'Uncategorized'}</Badge>
                    </td>
                    <td className="text-right p-2">{item.frequency}</td>
                    {analytics.totalRevenue > 0 && (
                      <>
                        <td className="text-right p-2">
                          {item.price ? `$${item.price.toFixed(2)}` : 'N/A'}
                        </td>
                        <td className="text-right p-2">
                          {item.price ? `$${(item.frequency * item.price).toFixed(2)}` : 'N/A'}
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}