import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { TransactionData } from './DataUpload';
import { 
  Brain, 
  TrendingUp, 
  Target, 
  Lightbulb, 
  Package, 
  Users, 
  MessageSquare,
  ArrowRight,
  Star,
  AlertCircle
} from 'lucide-react';

interface UserProfile {
  storeName: string;
  storeType: string;
  location: string;
  targetAudience: string;
  primaryProducts: string;
  storeSize: string;
  experience: string;
  goals: string;
  challenges: string;
  marketingBudget: string;
  preferredChannels: string[];
}

interface AIInsightsProps {
  data: TransactionData[];
  profile: UserProfile;
}

export function AIInsights({ data, profile }: AIInsightsProps) {
  const insights = useMemo(() => {
    // Analyze top categories
    const categoryAnalysis = data.reduce((acc, item) => {
      const category = item.category || 'Uncategorized';
      if (!acc[category]) {
        acc[category] = { frequency: 0, revenue: 0, items: [] };
      }
      acc[category].frequency += item.frequency;
      acc[category].revenue += item.frequency * (item.price || 0);
      acc[category].items.push(item.itemName);
      return acc;
    }, {} as Record<string, { frequency: number; revenue: number; items: string[] }>);

    const topCategory = Object.entries(categoryAnalysis)
      .sort(([,a], [,b]) => b.frequency - a.frequency)[0];

    const totalFrequency = data.reduce((sum, item) => sum + item.frequency, 0);
    const topItems = [...data].sort((a, b) => b.frequency - a.frequency).slice(0, 5);
    const lowPerformers = [...data].sort((a, b) => a.frequency - b.frequency).slice(0, 3);

    // Price analysis
    const avgPrice = data.filter(item => item.price).reduce((sum, item) => sum + (item.price || 0), 0) / data.filter(item => item.price).length;
    
    return {
      topCategory: topCategory?.[0] || 'Unknown',
      topCategoryPerformance: topCategory?.[1] || { frequency: 0, revenue: 0, items: [] },
      totalFrequency,
      topItems,
      lowPerformers,
      avgPrice: isNaN(avgPrice) ? 0 : avgPrice,
      categoryCount: Object.keys(categoryAnalysis).length
    };
  }, [data]);

  const generateMarketingStrategies = () => {
    const strategies = [];
    
    // Based on top category
    if (insights.topCategory === 'Fiction') {
      strategies.push({
        title: "Book Club Partnerships",
        description: "Partner with local book clubs to feature your top fiction titles. Offer group discounts and host monthly discussions.",
        priority: "High",
        channels: ["Local Events", "Social Media"]
      });
    } else if (insights.topCategory === 'Merchandise') {
      strategies.push({
        title: "Social Media Showcases",
        description: "Create Instagram posts featuring customers using your literary merchandise. Use hashtags like #BookishLife #LiteraryStyle",
        priority: "High",
        channels: ["Social Media"]
      });
    }

    // Based on budget
    if (profile.marketingBudget === 'minimal') {
      strategies.push({
        title: "Word-of-Mouth Referral Program",
        description: "Implement a customer referral program offering 10% off for both referrer and new customer. Cost-effective and builds loyalty.",
        priority: "Medium",
        channels: ["Word of Mouth", "Email Marketing"]
      });
    } else if (profile.marketingBudget === 'high') {
      strategies.push({
        title: "Author Event Series",
        description: "Host monthly author readings and signings. Partner with publishers to bring in emerging and established authors.",
        priority: "High",
        channels: ["Local Events", "Social Media", "Email Marketing"]
      });
    }

    // Based on store type and experience
    if (profile.storeType === 'independent-bookstore' && profile.experience === 'established') {
      strategies.push({
        title: "Community Literary Hub",
        description: "Position your store as the local literary center. Host writing workshops, poetry nights, and reading groups.",
        priority: "Medium",
        channels: ["Local Events", "Word of Mouth"]
      });
    }

    return strategies;
  };

  const generateInventoryRecommendations = () => {
    const recommendations = [];

    // Stock more of top performers
    if (insights.topItems.length > 0) {
      recommendations.push({
        type: "Increase Stock",
        items: insights.topItems.slice(0, 3).map(item => item.itemName),
        reason: "These items are your top performers. Consider increasing stock by 20-30%.",
        priority: "High"
      });
    }

    // Address low performers
    if (insights.lowPerformers.length > 0) {
      recommendations.push({
        type: "Review Low Performers",
        items: insights.lowPerformers.map(item => item.itemName),
        reason: "These items have low sales. Consider promotions, bundling, or discontinuing.",
        priority: "Medium"
      });
    }

    // Category-based recommendations
    if (insights.topCategory === 'Fiction') {
      recommendations.push({
        type: "Expand Category",
        items: ["Popular Fiction Series", "Local Author Works", "Book Club Selections"],
        reason: "Fiction is your strongest category. Expand with trending titles and local authors.",
        priority: "High"
      });
    } else if (insights.topCategory === 'Merchandise') {
      recommendations.push({
        type: "Seasonal Merchandise",
        items: ["Holiday-themed Items", "Literary Calendars", "Reading Accessories"],
        reason: "Merchandise performs well. Add seasonal and gift items for increased sales.",
        priority: "Medium"
      });
    }

    return recommendations;
  };

  const generateSocialMediaContent = () => {
    const contentIdeas = [];

    // Based on top items
    if (insights.topItems[0]) {
      contentIdeas.push({
        platform: "Instagram",
        type: "Customer Feature",
        content: `"Customer Spotlight: Why ${insights.topItems[0].itemName} is flying off our shelves! 📚✨ What's your favorite read this month?"`,
        hashtags: ["#BookLovers", "#CustomerChoice", "#BookRecommendation"]
      });
    }

    // Based on store type
    if (profile.storeType === 'independent-bookstore') {
      contentIdeas.push({
        platform: "Facebook",
        type: "Community Building",
        content: `"Supporting local authors and readers in ${profile.location}! Come discover your next favorite book with us. What makes our independent bookstore special to you?"`,
        hashtags: ["#IndependentBookstore", "#LocalBusiness", "#CommunityReads"]
      });
    }

    // Based on categories
    if (insights.topCategory === 'Fiction') {
      contentIdeas.push({
        platform: "TikTok",
        type: "Book Review",
        content: `"Quick review of our bestselling fiction titles! Which one should you read next? Comment your genre preference below! 👇"`,
        hashtags: ["#BookTok", "#FictionReads", "#BookRecommendations"]
      });
    }

    // General engagement content
    contentIdeas.push({
      platform: "Instagram Stories",
      type: "Behind the Scenes",
      content: `"Behind the scenes: How we curate our book selection! Today we're featuring books that pair perfectly with our ${insights.topCategory.toLowerCase()} collection."`,
      hashtags: ["#BehindTheScenes", "#BookCuration", "#BookstoreLife"]
    });

    return contentIdeas;
  };

  const marketingStrategies = generateMarketingStrategies();
  const inventoryRecommendations = generateInventoryRecommendations();
  const socialMediaContent = generateSocialMediaContent();

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>AI-Powered Business Insights</h1>
          <p className="text-muted-foreground">
            Personalized recommendations for {profile.storeName}
          </p>
        </div>
        <Badge variant="outline" className="bg-gradient-to-r from-purple-100 to-pink-100">
          <Brain className="w-4 h-4 mr-1" />
          AI Generated
        </Badge>
      </div>

      {/* Quick Insights Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              <p className="font-medium">Top Category</p>
            </div>
            <p className="text-2xl font-bold">{insights.topCategory}</p>
            <p className="text-sm text-muted-foreground">
              {((insights.topCategoryPerformance.frequency / insights.totalFrequency) * 100).toFixed(1)}% of total sales
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-5 w-5 text-green-500" />
              <p className="font-medium">Star Product</p>
            </div>
            <p className="text-lg font-bold">{insights.topItems[0]?.itemName || 'N/A'}</p>
            <p className="text-sm text-muted-foreground">
              {insights.topItems[0]?.frequency || 0} units sold
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="h-5 w-5 text-orange-500" />
              <p className="font-medium">Opportunity</p>
            </div>
            <p className="text-lg font-bold">
              {insights.categoryCount < 5 ? 'Expand Categories' : 'Optimize Mix'}
            </p>
            <p className="text-sm text-muted-foreground">
              {insights.categoryCount} product categories
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Marketing Strategies */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Marketing Strategy Recommendations
          </CardTitle>
          <CardDescription>
            Tailored strategies based on your profile and sales data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {marketingStrategies.map((strategy, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">{strategy.title}</h4>
                  <Badge variant={strategy.priority === 'High' ? 'default' : 'secondary'}>
                    {strategy.priority} Priority
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{strategy.description}</p>
                <div className="flex flex-wrap gap-2">
                  {strategy.channels.map((channel, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {channel}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Inventory Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Inventory Optimization
          </CardTitle>
          <CardDescription>
            Data-driven recommendations for your product mix
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {inventoryRecommendations.map((rec, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">{rec.type}</h4>
                  <Badge variant={rec.priority === 'High' ? 'default' : 'secondary'}>
                    {rec.priority} Priority
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{rec.reason}</p>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Recommended Items:</p>
                  <div className="flex flex-wrap gap-2">
                    {rec.items.map((item, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {item}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Social Media Content */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Social Media Content Ideas
          </CardTitle>
          <CardDescription>
            Ready-to-use content based on your best-selling items
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {socialMediaContent.map((content, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{content.platform}</Badge>
                  <Badge variant="secondary" className="text-xs">{content.type}</Badge>
                </div>
                <p className="text-sm mb-3">{content.content}</p>
                <div className="flex flex-wrap gap-1">
                  {content.hashtags.map((hashtag, idx) => (
                    <span key={idx} className="text-xs text-blue-600">
                      {hashtag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Items */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-blue-600" />
            This Week's Action Items
          </CardTitle>
          <CardDescription>
            Prioritized tasks to implement these insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-sm">
                Restock your top 3 performing items: {insights.topItems.slice(0, 3).map(item => item.itemName).join(', ')}
              </span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
              <span className="text-sm">
                Create social media posts featuring your {insights.topCategory.toLowerCase()} collection
              </span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
              <span className="text-sm">
                Plan a promotional campaign for underperforming items
              </span>
            </div>
            {profile.preferredChannels.includes('Local Events') && (
              <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                <span className="text-sm">
                  Reach out to local book clubs for partnership opportunities
                </span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* AI Enhancement Notice */}
      <Card className="border-dashed">
        <CardContent className="p-6 text-center">
          <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="font-medium mb-2">Enhance with Real AI Integration</h3>
          <p className="text-sm text-muted-foreground mb-4">
            These insights are generated from your data patterns. Connect to OpenAI API for more sophisticated, 
            real-time analysis and personalized recommendations.
          </p>
          <Button variant="outline" className="gap-2">
            Learn More <ArrowRight className="h-4 w-4" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}