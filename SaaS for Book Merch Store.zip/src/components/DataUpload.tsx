import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Upload, FileText, CheckCircle } from 'lucide-react';

export interface TransactionData {
  itemName: string;
  frequency: number;
  category?: string;
  price?: number;
  date?: string;
}

interface DataUploadProps {
  onDataUploaded: (data: TransactionData[]) => void;
}

export function DataUpload({ onDataUploaded }: DataUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
        setUploadError('Please select a CSV file');
        return;
      }
      setFile(selectedFile);
      setUploadError(null);
      setUploadSuccess(false);
    }
  };

  const parseCSV = (csvText: string): TransactionData[] => {
    const lines = csvText.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      throw new Error('CSV file must have at least a header and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    const data: TransactionData[] = [];

    // Check for required columns
    const itemNameIndex = headers.findIndex(h => 
      h.includes('item') || h.includes('product') || h.includes('name')
    );
    const frequencyIndex = headers.findIndex(h => 
      h.includes('frequency') || h.includes('quantity') || h.includes('count')
    );

    if (itemNameIndex === -1 || frequencyIndex === -1) {
      throw new Error('CSV must contain columns for item names and frequencies/quantities');
    }

    // Optional columns
    const categoryIndex = headers.findIndex(h => h.includes('category'));
    const priceIndex = headers.findIndex(h => h.includes('price'));
    const dateIndex = headers.findIndex(h => h.includes('date'));

    for (let i = 1; i < lines.length; i++) {
      const row = lines[i].split(',').map(cell => cell.trim());
      if (row.length >= Math.max(itemNameIndex, frequencyIndex) + 1) {
        const itemName = row[itemNameIndex];
        const frequency = parseInt(row[frequencyIndex]) || 0;
        
        if (itemName && frequency > 0) {
          data.push({
            itemName,
            frequency,
            category: categoryIndex >= 0 ? row[categoryIndex] : undefined,
            price: priceIndex >= 0 ? parseFloat(row[priceIndex]) || undefined : undefined,
            date: dateIndex >= 0 ? row[dateIndex] : undefined
          });
        }
      }
    }

    return data;
  };

  const handleUpload = async () => {
    if (!file) return;

    setIsUploading(true);
    setUploadError(null);

    try {
      const text = await file.text();
      const data = parseCSV(text);
      
      if (data.length === 0) {
        throw new Error('No valid transaction data found in CSV');
      }

      onDataUploaded(data);
      setUploadSuccess(true);
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : 'Failed to process CSV file');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    const droppedFile = event.dataTransfer.files[0];
    if (droppedFile) {
      if (droppedFile.type !== 'text/csv' && !droppedFile.name.endsWith('.csv')) {
        setUploadError('Please select a CSV file');
        return;
      }
      setFile(droppedFile);
      setUploadError(null);
      setUploadSuccess(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload Transaction Data</CardTitle>
          <CardDescription>
            Upload a CSV file containing your transaction history with item names and frequencies
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* CSV Format Instructions */}
          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium mb-2">CSV Format Requirements:</h4>
            <ul className="text-sm space-y-1 text-muted-foreground">
              <li>• Must include columns for item names and frequencies/quantities</li>
              <li>• Optional columns: category, price, date</li>
              <li>• Example headers: Item Name, Frequency, Category, Price, Date</li>
              <li>• First row should contain column headers</li>
            </ul>
          </div>

          {/* File Upload Area */}
          <div
            className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center cursor-pointer hover:border-muted-foreground/50 transition-colors"
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg mb-2">
              {file ? file.name : 'Drop your CSV file here or click to browse'}
            </p>
            <p className="text-sm text-muted-foreground">
              Supports CSV files up to 10MB
            </p>
          </div>

          <Input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Error Display */}
          {uploadError && (
            <Alert variant="destructive">
              <AlertDescription>{uploadError}</AlertDescription>
            </Alert>
          )}

          {/* Success Display */}
          {uploadSuccess && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Transaction data uploaded successfully! You can now view your analytics.
              </AlertDescription>
            </Alert>
          )}

          {/* Upload Button */}
          <div className="flex gap-4">
            <Button
              onClick={handleUpload}
              disabled={!file || isUploading || uploadSuccess}
              className="flex-1"
            >
              {isUploading ? 'Processing...' : 'Upload & Process Data'}
            </Button>
            {file && !uploadSuccess && (
              <Button
                variant="outline"
                onClick={() => {
                  setFile(null);
                  setUploadError(null);
                  if (fileInputRef.current) {
                    fileInputRef.current.value = '';
                  }
                }}
              >
                Clear
              </Button>
            )}
          </div>

          {/* Sample Data Option */}
          <div className="border-t pt-6">
            <p className="text-sm text-muted-foreground mb-3">
              Don't have data yet? Try our sample dataset:
            </p>
            <Button
              variant="outline"
              onClick={() => {
                const sampleData: TransactionData[] = [
                  { itemName: "Harry Potter Series", frequency: 45, category: "Fiction", price: 12.99 },
                  { itemName: "Coffee Mug - Literary Quotes", frequency: 32, category: "Merchandise", price: 8.99 },
                  { itemName: "The Great Gatsby", frequency: 28, category: "Classic Literature", price: 9.99 },
                  { itemName: "Bookmark Set", frequency: 67, category: "Accessories", price: 4.99 },
                  { itemName: "Dune", frequency: 23, category: "Science Fiction", price: 14.99 },
                  { itemName: "Tote Bag - Read More Books", frequency: 19, category: "Merchandise", price: 12.99 },
                  { itemName: "Pride and Prejudice", frequency: 31, category: "Romance", price: 8.99 },
                  { itemName: "Notebook - Writer's Journal", frequency: 26, category: "Stationery", price: 6.99 },
                  { itemName: "1984", frequency: 22, category: "Dystopian Fiction", price: 10.99 },
                  { itemName: "Reading Light", frequency: 15, category: "Accessories", price: 19.99 }
                ];
                onDataUploaded(sampleData);
                setUploadSuccess(true);
              }}
              className="w-full"
            >
              <FileText className="w-4 h-4 mr-2" />
              Use Sample Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}