import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

interface UserProfile {
  storeName: string;
  storeType: string;
  location: string;
  targetAudience: string;
  primaryProducts: string;
  storeSize: string;
  experience: string;
  goals: string;
  challenges: string;
  marketingBudget: string;
  preferredChannels: string[];
}

interface QuestionnaireProps {
  onComplete: (profile: UserProfile) => void;
}

export function Questionnaire({ onComplete }: QuestionnaireProps) {
  const [profile, setProfile] = useState<UserProfile>({
    storeName: '',
    storeType: '',
    location: '',
    targetAudience: '',
    primaryProducts: '',
    storeSize: '',
    experience: '',
    goals: '',
    challenges: '',
    marketingBudget: '',
    preferredChannels: []
  });

  const [currentStep, setCurrentStep] = useState(0);

  const handleChannelChange = (channel: string, checked: boolean) => {
    setProfile(prev => ({
      ...prev,
      preferredChannels: checked 
        ? [...prev.preferredChannels, channel]
        : prev.preferredChannels.filter(c => c !== channel)
    }));
  };

  const steps = [
    {
      title: "Store Information",
      description: "Tell us about your book and merchandise store",
      content: (
        <div className="space-y-4">
          <div>
            <Label htmlFor="storeName">Store Name</Label>
            <Input
              id="storeName"
              value={profile.storeName}
              onChange={(e) => setProfile(prev => ({ ...prev, storeName: e.target.value }))}
              placeholder="Enter your store name"
            />
          </div>
          <div>
            <Label htmlFor="storeType">Store Type</Label>
            <Select onValueChange={(value) => setProfile(prev => ({ ...prev, storeType: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select store type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="independent-bookstore">Independent Bookstore</SelectItem>
                <SelectItem value="specialty-bookstore">Specialty Bookstore</SelectItem>
                <SelectItem value="book-merch-combo">Book + Merchandise Store</SelectItem>
                <SelectItem value="online-store">Online Store</SelectItem>
                <SelectItem value="pop-up-store">Pop-up Store</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={profile.location}
              onChange={(e) => setProfile(prev => ({ ...prev, location: e.target.value }))}
              placeholder="City, State/Country"
            />
          </div>
        </div>
      )
    },
    {
      title: "Business Details",
      description: "Help us understand your business better",
      content: (
        <div className="space-y-4">
          <div>
            <Label>Store Size</Label>
            <RadioGroup
              value={profile.storeSize}
              onValueChange={(value) => setProfile(prev => ({ ...prev, storeSize: value }))}
              className="mt-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="small" id="small" />
                <Label htmlFor="small">Small (&lt; 1,000 sq ft)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="medium" id="medium" />
                <Label htmlFor="medium">Medium (1,000-3,000 sq ft)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="large" id="large" />
                <Label htmlFor="large">Large (&gt; 3,000 sq ft)</Label>
              </div>
            </RadioGroup>
          </div>
          <div>
            <Label htmlFor="experience">Years in Business</Label>
            <Select onValueChange={(value) => setProfile(prev => ({ ...prev, experience: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select experience level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="new">New (&lt; 1 year)</SelectItem>
                <SelectItem value="emerging">Emerging (1-3 years)</SelectItem>
                <SelectItem value="established">Established (3-10 years)</SelectItem>
                <SelectItem value="veteran">Veteran (10+ years)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="primaryProducts">Primary Products</Label>
            <Textarea
              id="primaryProducts"
              value={profile.primaryProducts}
              onChange={(e) => setProfile(prev => ({ ...prev, primaryProducts: e.target.value }))}
              placeholder="Describe your main product categories (e.g., fiction books, graphic novels, literary merchandise, etc.)"
            />
          </div>
        </div>
      )
    },
    {
      title: "Target Audience & Goals",
      description: "Who do you serve and what are your objectives?",
      content: (
        <div className="space-y-4">
          <div>
            <Label htmlFor="targetAudience">Target Audience</Label>
            <Textarea
              id="targetAudience"
              value={profile.targetAudience}
              onChange={(e) => setProfile(prev => ({ ...prev, targetAudience: e.target.value }))}
              placeholder="Describe your typical customers (age, interests, reading preferences, etc.)"
            />
          </div>
          <div>
            <Label htmlFor="goals">Business Goals</Label>
            <Textarea
              id="goals"
              value={profile.goals}
              onChange={(e) => setProfile(prev => ({ ...prev, goals: e.target.value }))}
              placeholder="What are your main business objectives? (e.g., increase sales, expand customer base, improve inventory turnover)"
            />
          </div>
          <div>
            <Label htmlFor="challenges">Current Challenges</Label>
            <Textarea
              id="challenges"
              value={profile.challenges}
              onChange={(e) => setProfile(prev => ({ ...prev, challenges: e.target.value }))}
              placeholder="What challenges are you currently facing? (e.g., slow-moving inventory, competition, customer acquisition)"
            />
          </div>
        </div>
      )
    },
    {
      title: "Marketing Preferences",
      description: "Let us know about your marketing approach",
      content: (
        <div className="space-y-4">
          <div>
            <Label>Monthly Marketing Budget</Label>
            <RadioGroup
              value={profile.marketingBudget}
              onValueChange={(value) => setProfile(prev => ({ ...prev, marketingBudget: value }))}
              className="mt-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="minimal" id="minimal" />
                <Label htmlFor="minimal">Minimal (&lt; $100)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="low" id="low" />
                <Label htmlFor="low">Low ($100-$500)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="moderate" id="moderate" />
                <Label htmlFor="moderate">Moderate ($500-$1,500)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="high" id="high" />
                <Label htmlFor="high">High ($1,500+)</Label>
              </div>
            </RadioGroup>
          </div>
          <div>
            <Label>Preferred Marketing Channels (Select all that apply)</Label>
            <div className="mt-2 space-y-2">
              {['Social Media', 'Email Marketing', 'Local Events', 'Book Clubs', 'Author Events', 'Online Advertising', 'Print Advertising', 'Word of Mouth'].map((channel) => {
                const channelId = channel.toLowerCase().replace(/\s+/g, '-');
                return (
                  <div key={channel} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={channelId}
                      checked={profile.preferredChannels.includes(channel)}
                      onChange={(e) => handleChannelChange(channel, e.target.checked)}
                      className="rounded border-gray-300"
                    />
                    <Label htmlFor={channelId}>{channel}</Label>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )
    }
  ];

  const isStepComplete = () => {
    switch (currentStep) {
      case 0:
        return profile.storeName && profile.storeType && profile.location;
      case 1:
        return profile.storeSize && profile.experience && profile.primaryProducts;
      case 2:
        return profile.targetAudience && profile.goals && profile.challenges;
      case 3:
        return profile.marketingBudget && profile.preferredChannels.length > 0;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(profile);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>{steps[currentStep].title}</CardTitle>
          <CardDescription>{steps[currentStep].description}</CardDescription>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground">Step {currentStep + 1} of {steps.length}</p>
        </CardHeader>
        <CardContent>
          {steps[currentStep].content}
          <div className="flex justify-between mt-6">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0}
            >
              Back
            </Button>
            <Button
              onClick={handleNext}
              disabled={!isStepComplete()}
            >
              {currentStep === steps.length - 1 ? 'Complete Profile' : 'Next'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}