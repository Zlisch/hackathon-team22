import { useState } from 'react';
import { Questionnaire } from './components/Questionnaire';
import { DataUpload, TransactionData } from './components/DataUpload';
import { Analytics } from './components/Analytics';
import { AIInsights } from './components/AIInsights';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { 
  BookOpen, 
  BarChart3, 
  Brain, 
  Upload, 
  ChevronLeft,
  CheckCircle,
  ArrowRight
} from 'lucide-react';

interface UserProfile {
  storeName: string;
  storeType: string;
  location: string;
  targetAudience: string;
  primaryProducts: string;
  storeSize: string;
  experience: string;
  goals: string;
  challenges: string;
  marketingBudget: string;
  preferredChannels: string[];
}

type AppStep = 'welcome' | 'questionnaire' | 'upload' | 'analytics' | 'insights';

export default function App() {
  const [currentStep, setCurrentStep] = useState<AppStep>('welcome');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [transactionData, setTransactionData] = useState<TransactionData[]>([]);

  const handleProfileComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setCurrentStep('upload');
  };

  const handleDataUploaded = (data: TransactionData[]) => {
    setTransactionData(data);
    setCurrentStep('analytics');
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 'welcome':
        return (
          <div className="max-w-4xl mx-auto p-6 text-center space-y-8">
            <div className="space-y-4">
              <BookOpen className="h-16 w-16 mx-auto text-primary" />
              <h1 className="text-4xl">BookStore Insights</h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Your intelligent SaaS platform for optimizing book and merchandise store operations through data-driven insights and AI-powered recommendations.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="font-medium mb-2">Store Profiling</h3>
                  <p className="text-sm text-muted-foreground">
                    Create a detailed profile of your bookstore to personalize insights
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="font-medium mb-2">Sales Analytics</h3>
                  <p className="text-sm text-muted-foreground">
                    Visualize transaction history with interactive charts and metrics
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Brain className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="font-medium mb-2">AI Insights</h3>
                  <p className="text-sm text-muted-foreground">
                    Get personalized marketing and inventory recommendations
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Button 
                size="lg" 
                onClick={() => setCurrentStep('questionnaire')}
                className="gap-2"
              >
                Get Started <ArrowRight className="h-4 w-4" />
              </Button>
              <p className="text-sm text-muted-foreground">
                Takes 3-5 minutes to complete setup
              </p>
            </div>
          </div>
        );

      case 'questionnaire':
        return <Questionnaire onComplete={handleProfileComplete} />;

      case 'upload':
        return <DataUpload onDataUploaded={handleDataUploaded} />;

      case 'analytics':
        return <Analytics data={transactionData} />;

      case 'insights':
        return userProfile ? (
          <AIInsights data={transactionData} profile={userProfile} />
        ) : null;

      default:
        return null;
    }
  };

  const getStepNumber = (step: AppStep): number => {
    const steps = ['welcome', 'questionnaire', 'upload', 'analytics', 'insights'];
    return steps.indexOf(step) + 1;
  };

  const isStepCompleted = (step: AppStep): boolean => {
    switch (step) {
      case 'welcome':
        return currentStep !== 'welcome';
      case 'questionnaire':
        return userProfile !== null;
      case 'upload':
        return transactionData.length > 0;
      case 'analytics':
        return transactionData.length > 0 && ['analytics', 'insights'].includes(currentStep);
      case 'insights':
        return currentStep === 'insights';
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      {currentStep !== 'welcome' && (
        <header className="border-b bg-white sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    if (currentStep === 'questionnaire') setCurrentStep('welcome');
                    else if (currentStep === 'upload') setCurrentStep('questionnaire');
                    else if (currentStep === 'analytics') setCurrentStep('upload');
                    else if (currentStep === 'insights') setCurrentStep('analytics');
                  }}
                  className="gap-2"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Back
                </Button>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-6 w-6 text-primary" />
                  <span className="font-medium">BookStore Insights</span>
                  {userProfile && (
                    <Badge variant="outline" className="text-xs">
                      {userProfile.storeName}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Navigation Steps */}
              <div className="flex items-center gap-6">
                {[
                  { step: 'questionnaire', label: 'Profile', icon: BookOpen },
                  { step: 'upload', label: 'Data', icon: Upload },
                  { step: 'analytics', label: 'Analytics', icon: BarChart3 },
                  { step: 'insights', label: 'Insights', icon: Brain }
                ].map(({ step, label, icon: Icon }) => (
                  <div
                    key={step}
                    className={`flex items-center gap-2 text-sm ${
                      currentStep === step 
                        ? 'text-primary font-medium' 
                        : isStepCompleted(step as AppStep)
                        ? 'text-green-600'
                        : 'text-muted-foreground'
                    }`}
                  >
                    {isStepCompleted(step as AppStep) ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      <Icon className="h-4 w-4" />
                    )}
                    <span className="hidden sm:inline">{label}</span>
                  </div>
                ))}
              </div>

              {/* Quick Actions */}
              {transactionData.length > 0 && (
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentStep('analytics')}
                    disabled={currentStep === 'analytics'}
                  >
                    Analytics
                  </Button>
                  {userProfile && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setCurrentStep('insights')}
                      disabled={currentStep === 'insights'}
                    >
                      AI Insights
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main className="flex-1">
        {renderStepContent()}
      </main>

      {/* Footer */}
      {currentStep !== 'welcome' && (
        <footer className="border-t bg-muted/50 py-6">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <p className="text-sm text-muted-foreground">
              BookStore Insights - Empowering independent bookstores with data-driven decisions
            </p>
          </div>
        </footer>
      )}
    </div>
  );
}